// Re-export the useAuth hook from the AuthContext
export { useAuth } from "@/contexts/AuthContext"; 